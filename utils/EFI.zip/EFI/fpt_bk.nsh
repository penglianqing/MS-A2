Fpt.efi -d backup.bin
